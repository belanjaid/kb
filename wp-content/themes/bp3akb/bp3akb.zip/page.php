<?php get_header(); ?>
<div id="ttr_content_and_sidebar_container">
<div id="ttr_content">
<div id="ttr_content_margin">
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<?php if (get_option("ttr_page_breadcrumb",true)):?>
<?php wordpress_breadcrumbs(); ?>
<?php endif; ?>
<?php while ( have_posts() ) : the_post(); ?>
<?php get_template_part( 'content', 'page' ); ?>
<?php comments_template( '', true ); ?>
<?php endwhile; // end of the loop. ?>
<?php
if( is_active_sidebar( 'contentbottomcolumn1'  )):
?>
<div class="contentbottomcolumn0">
<?php if ( is_active_sidebar('contentbottomcolumn1') ) : ?>
<div class="cell1 col-lg-12 col-md-12 col-sm-12  col-xs-12">
<div class="bottomcolumn1">
<?php theme_dynamic_sidebar( 'footer'); ?>
</div>
</div>
<?php else: ?>
<div class="cell1 col-lg-12 col-md-12 col-sm-12  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block">
</div>
</div>
<?php endif; ?>
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
</div>
</div>
<aside id="ttr_sidebar_left">
<?php get_sidebar('2'); ?>
 </aside> 
<div style="clear:both;">
</div>
</div>
<?php get_footer(); ?>
