<div id="ttr_sidebar_right_margin"> 
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<div class="ttr_sidebar_right_padding"> 
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<?php if(!theme_dynamic_sidebar(2)){
global $theme_widget_args;
extract($theme_widget_args);

}
?>
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
</div>
</div>
