<!DOCTYPE html>
<!--[if IE 6]>
<html id="ie6" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 7]>
<html id="ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html id="ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 6) | !(IE 7) | !(IE 8)  ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<?php $seomode = get_option('ttr_seo_enable');
if($seomode=='on'){
?>
<title>
<?php
if(get_option('ttr_seo_rewrite_titles', true)){rewrite_titles();}
else {original_titles();}
?>
</title>
<?php wp_head(); ?>
<meta name="viewport" content="width=device-width">
<meta name="keywords" content="<?php if(get_option('ttr_seo_use_keywords',true)){get_keywords();}?>"/>
<meta name="description" content="<?php get_description();?>"/>
<?php
}
else{
?>
<title><?php wp_title( '|', true, 'right' ); ?></title>
<?php wp_head(); ?>
<meta name="viewport" content="width=device-width">
<meta name="description" content="Add the site description here">
<meta  name="keywords" content="First keyword, second keyword,">
<?php }
?>
<?php $theme_path = get_template_directory_uri(); ?>
<script type="text/javascript">
jQuery(document).ready(function(){
 jQuery("#wp-submit").addClass(" btn btn-default");
 });
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
var inputs = document.getElementsByTagName('input');
for (a = 0; a < inputs.length; a++) {
if (inputs[a].type == "checkbox") {
var id = inputs[a].getAttribute("id");
if (id==null){
id=  "checkbox" +a;
}
inputs[a].setAttribute("id",id);
var container = document.createElement('div');
container.setAttribute("class", "ttr_checkbox");
var label = document.createElement('label');
label.setAttribute("for", id);
jQuery(inputs[a]).wrap(container).after(label);
}
}
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
var inputs = document.getElementsByTagName('input');
for (a = 0; a < inputs.length; a++) {
if (inputs[a].type == "radio") {
var id = inputs[a].getAttribute("id");
if (id==null){
id=  "radio" +a;
}
inputs[a].setAttribute("id",id);
var container = document.createElement('div');
container.setAttribute("class", "ttr_radio");
var label = document.createElement('label');
label.setAttribute("for", id);
jQuery(inputs[a]).wrap(container).after(label);
}
}
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('#ttr_slideshow_inner').TTSlider({
slideShowSpeed:2000,cssPrefix: 'ttr_'
});
});
</script>
<script type="text/javascript" src="<?php echo $theme_path?>/js/jquery-ui-1.10.4.custom.min.js">
</script>
<script type="text/javascript" src="<?php echo $theme_path?>/js/tt_slideshow.js">
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
var window_height =  Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
var body_height = jQuery(document.body).height();
var content = jQuery("#ttr_content_and_sidebar_container");
if(body_height < window_height){
differ = (window_height - body_height);
content_height = content.height() + differ;
jQuery("#ttr_content_and_sidebar_container").css("min-height", content_height+"px");
}
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('#nav-expander').on('click',function(e){
e.preventDefault();
jQuery('body').toggleClass('nav-expanded');
});
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('ul.ttr_menu_items.nav li [data-toggle=dropdown]').on('click', function() {
var window_width =  Math.max(document.documentElement.clientWidth, window.innerWidth || 0)
window.location.href = jQuery(this).attr('href'); 
});
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('.ttr_menu_items ul.dropdown-menu [data-toggle=dropdown]').on('click', function(event) { 
var window_width =  Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
if(window_width < 1025){
event.preventDefault();
event.stopPropagation();
jQuery(this).parent().siblings().removeClass('open');
jQuery(this).parent().toggleClass(function() {
if (jQuery(this).is(".open") ) {
window.location.href = jQuery(this).children("[data-toggle=dropdown]").attr('href'); 
return "";
} else {
return "open";
}
});
}
});
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('.ttr_vmenu_items ul.dropdown-menu [data-toggle=dropdown]').on('click', function(event) { 
var window_width =  Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
event.preventDefault();
event.stopPropagation();
jQuery(this).parent().siblings().removeClass('open');
jQuery(this).parent().toggleClass(function() {
if (jQuery(this).is(".open") ) {
window.location.href = jQuery(this).children("[data-toggle=dropdown]").attr('href'); 
return "";
} else {
return "open";
}
});
});
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
var objects = ['iframe', 'video','object'];
for(var i = 0 ; i < objects.length ; i++){
if (jQuery(objects[i]).length > 0) {
jQuery(objects[i]).addClass('embed-responsive-item');
jQuery(objects[i]).parent().addClass('embed-responsive embed-responsive-16by9');
jQuery(".embed-responsive-16by9").css("padding-bottom","56.25%");
}
}
});
</script>
<script type="text/javascript">
WebFontConfig = {
google: { families: [ 'Playball','Ubuntu'] }
};
(function() {
var wf = document.createElement('script');
wf.src = ('https:' == document.location.protocol ? 'https' : 'http') + '://ajax.googleapis.com/ajax/libs/webfont/1.0.31/webfont.js';
wf.type = 'text/javascript';
wf.async = 'true';
var s = document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(wf, s);
})();
</script>
<?php global $mhicon;
$mhicon = false;
$seomode = get_option('ttr_seo_enable');
 if($seomode=="on" ){
$google_webmaster= get_option('ttr_seo_google_webmaster');
$bing_webmaster= get_option('ttr_seo_bing_webmaster');
$pinterst_webmaster=get_option('ttr_seo_pinterst_webmaster');
if(!empty($google_webmaster))
echo sprintf("<meta name=\"google-site-verification\" content=\"%s\"/>\n", $google_webmaster);
if(!empty($bing_webmaster))
echo sprintf("<meta name=\"msvalidate.01\" content=\"%s\"/>\n", $bing_webmaster);
if(!empty($pinterst_webmaster))
echo sprintf("<meta name=\"p:domain_verify\" content=\"%s\"/>\n", $pinterst_webmaster);
if ((is_page() || is_single()) ) {
$profile=get_option('ttr_seo_google_plus');
if(!empty($profile)){echo '<link href="' . $profile. '" rel="author"/>';}
else{ $profile=get_option('googleplus');echo '<link href="' . $profile. '" rel="author" />';}
}
if(get_option('ttr_seo_canonical_urls',true)) {
if ( is_singular() ) echo '<link rel="canonical" href="' . get_permalink() . '" />';
}
$blog_title=get_option('blogname');
$blog_desciprtion= get_option('blogdescription');
$theme_path = get_template_directory_uri();
if(is_single()) {
if (get_option('ttr_seo_nonindex_post',true)){	$noindex = "noindex";}
else{$noindex = "index";}
if (get_option('ttr_seo_nofollow_post',true)){$nofollow = "nofollow";}
else{$nofollow = "follow";}
echo sprintf("<!--Add by easy-noindex-nofollow--><meta name=\"robots\" content=\"%s, %s\"/>\n", $noindex, $nofollow);}
else if(is_attachment()) {
if (get_option('ttr_seo_nonindex_media',true)){	$noindex = "noindex";}
else{$noindex = "index";}
if (get_option('ttr_seo_nofollow_media',true)){$nofollow = "nofollow";}
else{$nofollow = "follow";}
echo sprintf("<!--Add by easy-noindex-nofollow--><meta name=\"robots\" content=\"%s, %s\"/>\n", $noindex, $nofollow);}
else if(is_home() || is_page() || is_paged()){
if (get_option('ttr_seo_nonindex_page',true)){	$noindex = "noindex";}
else{$noindex = "index";}
if (get_option('ttr_seo_nofollow_page',true)){$nofollow = "nofollow";}
else{$nofollow = "follow";}
echo sprintf("<!--Add by easy-noindex-nofollow--><meta name=\"robots\" content=\"%s, %s\"/>\n", $noindex, $nofollow);}
else if(is_date()){
if (get_option('ttr_seo_noindex_date_archive',true)){	$noindex = "noindex";}
else{$noindex = "index";}
echo sprintf("<!--Add by easy-noindex--><meta name=\"robots\" content=\"%s\"/>\n", $noindex);}
else if(is_author() ){
if (get_option('ttr_seo_noindex_author_archive',true)){	$noindex = "noindex";}
else{$noindex = "index";}
echo sprintf("<!--Add by easy-noindex--><meta name=\"robots\" content=\"s\"/>\n", $noindex);}
else if(is_tag() ){
if (get_option('ttr_seo_noindex_tag_archive',true)){	$noindex = "noindex";}
else{$noindex = "index";}
echo sprintf("<!--Add by easy-noindex--><meta name=\"robots\" content=\"%s\"/>\n", $noindex);}
?>
<?php if(is_search()){
if (get_option('ttr_seo_noindex_search',true)){	$noindex = "noindex";}
else{$noindex = "index";}
if (get_option('ttr_seo_nofollow_search',true)){$nofollow = "nofollow";}
else{$nofollow = "follow";}
echo sprintf("<!--Add by easy-noindex-nofollow--><meta name=\"robots\" content=\"%s, %s\"/>\n", $noindex, $nofollow);}
if(is_category()){
if (get_option('ttr_seo_noindex_categories',true)){	$noindex = "noindex";}
else{$noindex = "index";}
if (get_option('ttr_seo_nofollow_categories',true)){$nofollow = "nofollow";}
else{$nofollow = "follow";}
echo sprintf("<!--Add by easy-noindex-nofollow--><meta name=\"robots\" content=\"%s, %s\"/>\n", $noindex, $nofollow);}
$home_header= get_option('ttr_seo_additional_fpage_header');
$page_header= get_option('ttr_seo_additional_post_header');
$post_header= get_option('ttr_seo_additional_page_header');
if(is_home()&& !empty($home_header)){echo '<center><h1>'.$home_header.'</h1></center>';}
else if(is_single()&& !empty($page_header)){echo '<center><h1>'.$page_header.'</h1></center>';}
else if(is_page()&& !empty($post_header)){echo '<center><h1>'.$post_header.'</h1></center>';}
}?>
<link rel="stylesheet"  href="<?php bloginfo( 'stylesheet_url' ); ?>" type="text/css" media="screen"/>
<!--[if lte IE 8]>
<link rel="stylesheet"  href="<?php echo get_template_directory_uri() ?>/menuie.css" type="text/css" media="screen"/>
<link rel="stylesheet"  href="<?php echo get_template_directory_uri() ?>/vmenuie.css" type="text/css" media="screen"/>
<![endif]-->
<script type="text/javascript" src="<?php echo $theme_path?>/js/prefixfree.min.js">
</script>
<?php if(isset($_POST['wp_customize']) && $_POST['wp_customize']=='on'):?>
<link type="image/vnd.microsoft.icon" rel="shortcut icon"  href="<?php echo get_template_directory_uri().'/favicon.ico';?>"/>
<?php else: ?>
<link type="image/vnd.microsoft.icon" rel="shortcut icon"  href="<?php echo get_option('ttr_favicon_image',get_template_directory_uri().'/favicon.ico');?>"/>
<?php endif; ?>
<!--[if IE 7]>
<style type="text/css" media="screen">
#ttr_vmenu_items  li.ttr_vmenu_items_parent {display:inline;}
</style>
<![endif]-->
<style>
</style>
<?php if (get_option('ttr_custom_style')):?>
<style>
<?php $custom_style = get_option('ttr_custom_style');
echo $custom_style;?>
</style>
<?php endif;?>
<!--[if lt IE 9]>
<script type="text/javascript" src="<?php echo $theme_path?>/js/html5shiv.js">
</script>
<script type="text/javascript" src="<?php echo $theme_path?>/js/respond.min.js">
</script>
<![endif]-->
</head>
<body <?php body_class(); ?>>
<div id="ttr_page" class="container">
<div class="ttr_banner_slideshow">
<?php
if( is_active_sidebar( 'slideshowabovecolumn1'  )):
?>
<div class="ttr_banner_slideshow_inner_above0">
<?php if ( is_active_sidebar('slideshowabovecolumn1') ) : ?>
<div class="cell1 col-lg-12 col-md-12 col-sm-12  col-xs-12">
<div class="slideshowabovecolumn1">
<?php theme_dynamic_sidebar( 'lagu'); ?>
</div>
</div>
<?php else: ?>
<div class="cell1 col-lg-12 col-md-12 col-sm-12  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block">
</div>
</div>
<?php endif; ?>
</div>
<div class="ttr_slideshow">
<div id="ttr_slideshow_inner">
<div id="Slide0" class="ttr_slide" data-slideEffect="None">
<div class="ttr_slideshow_last">
<div class="slideshowforeground01" data-effect="RadialBlur" data-begintime="0" data-duration="3" data-easing="linear" data-slide="None">
</div>
<div class="ttr_slideshowshape01" data-effect="None" data-begintime="2" data-duration="1" data-easing="linear" data-slide="None">
<div class="html_content" style="font-family:Times New Roman;font-size:12px;"><p style="text-align:Center;font-family:Times New Roman;font-size:12px;"><span style="font-family:&quot;Trajan Pro&quot;;font-size:48px;">SELAMAT</span></p><p style="text-align:Center;font-family:Times New Roman;font-size:12px;"><br style="font-family:&quot;Trajan Pro&quot;;font-size:48px;" /></p><p style="text-align:Center;font-family:Times New Roman;font-size:12px;"><span style="font-family:&quot;Trajan Pro&quot;;font-size:48px;">DATANG</span></p></div>
</div>
<div class="ttr_slideshowshape02" data-effect="None" data-begintime="2" data-duration="1" data-easing="linear" data-slide="None">
<div class="html_content" style="font-family:Times New Roman;font-size:12px;"><p style="text-align:Center;font-family:Times New Roman;font-size:12px;"><span style="font-family:&quot;Trajan Pro&quot;;font-size:36px;">DI SITUS RESMI BP3AKB</span></p><p style="text-align:Center;font-family:Times New Roman;font-size:12px;"><br style="font-family:&quot;Trajan Pro&quot;;font-size:36px;" /></p><p style="text-align:Center;font-family:Times New Roman;font-size:12px;"><span style="font-family:&quot;Trajan Pro&quot;;font-size:36px;">PEMERINTAH KOTA</span></p><p style="text-align:Center;font-family:Times New Roman;font-size:12px;"><span style="font-family:&quot;Trajan Pro&quot;;font-size:36px;">BEKASI</span></p></div>
</div>
</div>
</div>
<div id="Slide1" class="ttr_slide" data-slideEffect="RadialBlur">
<div class="ttr_slideshow_last">
<div class="slideshowforeground11" data-effect="RadialBlur" data-begintime="0" data-duration="1" data-easing="linear" data-slide="left">
</div>
<div class="slideshowforeground12" data-effect="RadialBlur" data-begintime="0" data-duration="1" data-easing="easeInOutBounce" data-slide="bottom">
</div>
<div class="slideshowforeground13" data-effect="Fade" data-begintime="0" data-duration="1" data-easing="linear" data-slide="bottom">
</div>
<a href="http://www.bp3akb.bekasikota.go.id" class="slideshowforeground14" data-effect="RadialBlur" data-begintime="0" data-duration="1" data-easing="easeInOutBounce" data-slide="left">
</a>
<div class="slideshowforeground15" data-effect="None" data-begintime="1" data-duration="1" data-easing="linear" data-slide="bottom">
</div>
<div class="ttr_slideshowshape11" data-effect="None" data-begintime="0" data-duration="1" data-easing="easeInOutBounce" data-slide="bottom">
<div class="html_content" style="font-family:Times New Roman;font-size:12px;"><p><span><button onclick="location.href='http://www.bp3akb.bekasikota.go.id/strukturnya'" target="_self" type="button" class="btn btn-default">STRUKTUR ORGANISASI BP3AKB</button></span></p></div>
</div>
<div class="ttr_slideshowshape12" data-effect="None" data-begintime="1" data-duration="1" data-easing="easeInOutBounce" data-slide="top">
<div class="html_content" style="font-family:Times New Roman;font-size:12px;"><p><span style="font-size:55px;color:#000203;font-family:Times New Roman;">VISI</span></p></div>
</div>
<div class="ttr_slideshowshape13" data-effect="RadialBlur" data-begintime="0" data-duration="1" data-easing="easeInOutBounce" data-slide="bottom">
<div class="html_content" style="font-family:Times New Roman;font-size:12px;"><p><span style="font-size:18px;color:#000203;font-family:Times New Roman;">1.Keluarga Mandiri</span></p><p><span style="font-size:18px;color:#000203;font-family:Times New Roman;">2.Keluarga Sehat</span></p><p><span style="font-size:18px;color:#000203;font-family:Times New Roman;">3.Keluarga Sejahtera</span></p></div>
</div>
<div class="ttr_slideshowshape14" data-effect="RadialBlur" data-begintime="0" data-duration="3" data-easing="easeInOutBounce" data-slide="bottom">
<div class="html_content" style="font-family:Times New Roman;font-size:12px;"><p><span style="font-weight:bold;font-size:72px;color:#000101;font-family:Times New Roman;">MISI</span></p></div>
</div>
<div class="ttr_slideshowshape15" data-effect="Fade" data-begintime="0" data-duration="1" data-easing="easeInOutBounce" data-slide="bottom">
<div class="html_content" style="font-family:Times New Roman;font-size:12px;"><p><span style="font-weight:bold;font-size:16px;color:#000205;font-family:Times New Roman;">1.Mewujudkan keluarga yang berkualitas</span></p><p><br style="font-weight:bold;font-size:16px;color:#000205;font-family:Times New Roman;" /></p><p><span style="font-weight:bold;font-size:16px;color:#000205;font-family:Times New Roman;">2.Mewujudkan kesetaraan dan keadilan gender serta perlindungan Perempuan dan anak</span></p><p><br style="font-weight:bold;font-size:16px;color:#000205;font-family:Times New Roman;" /></p><p><span style="font-weight:bold;font-size:16px;color:#000205;font-family:Times New Roman;">4.Mewujudkan Bekasi sebagai Kota Layak Anak</span></p></div>
</div>
</div>
</div>
<div id="Slide2" class="ttr_slide" data-slideEffect="None">
<div class="ttr_slideshow_last">
<div class="slideshowforeground21" data-effect="Fade" data-begintime="0" data-duration="2" data-easing="easeInOutBack" data-slide="left">
</div>
</div>
</div>
<div id="Slide3" class="ttr_slide" data-slideEffect="None">
<div class="ttr_slideshow_last">
<div class="slideshowforeground31" data-effect="RadialBlur" data-begintime="0" data-duration="2" data-easing="linear" data-slide="None">
</div>
</div>
</div>
<div id="Slide4" class="ttr_slide" data-slideEffect="None">
<div class="ttr_slideshow_last">
<div class="slideshowforeground41" data-effect="None" data-begintime="0" data-duration="1" data-easing="linear" data-slide="left">
</div>
<div class="slideshowforeground42" data-effect="None" data-begintime="0" data-duration="1" data-easing="linear" data-slide="right">
</div>
<div class="slideshowforeground43" data-effect="RadialBlur" data-begintime="0" data-duration="1" data-easing="linear" data-slide="None">
</div>
<div class="ttr_slideshowshape41" data-effect="RadialBlur" data-begintime="0" data-duration="2" data-easing="linear" data-slide="None">
<div class="html_content" style="font-family:Times New Roman;font-size:12px;"><p style="text-align:Center;font-family:Times New Roman;font-size:12px;"><span style="font-family:&quot;Showcard Gothic&quot;;font-size:24px;color:#010000;">BEKASI MAJU, SEJAHTERA, IHSAN</span></p></div>
</div>
</div>
</div>
</div>
<div class="ttr_slideshow_in">
<div class="ttr_slideshow_last">
<div id="nav"></div>
</div>
</div>
</div>
<div class="ttr_banner_slideshow">
</div>
<div class="ttr_banner_menu">
</div>
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<nav id="ttr_menu" class="navbar-default navbar">
   <div id="ttr_menu_inner_in">
<div class="menuforeground">
</div>
<div id="navigationmenu">
<div class="navbar-header">
<button id="nav-expander" data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
<span class="sr-only">
</span>
<span class="icon-bar">
</span>
<span class="icon-bar">
</span>
<span class="icon-bar">
</span>
</button>
</div>
<div class="menu-center collapse navbar-collapse">
<ul class="ttr_menu_items nav navbar-nav navbar-left">
<?php echo theme_nav_menu('ttr_','primary','menu',True,True,False,False);?>
</ul>
</div>
</div>
</div>
</nav>
<div class="ttr_banner_menu">
<?php
if( is_active_sidebar( 'menubelowcolumn1'  )):
?>
<div class="ttr_banner_menu_inner_below0">
<?php if ( is_active_sidebar('menubelowcolumn1') ) : ?>
<div class="cell1 col-lg-12 col-md-12 col-sm-12  col-xs-12">
<div class="menubelowcolumn1">
<?php theme_dynamic_sidebar( 'kontent utama'); ?>
</div>
</div>
<?php else: ?>
<div class="cell1 col-lg-12 col-md-12 col-sm-12  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block">
</div>
</div>
<?php endif; ?>
</div>
