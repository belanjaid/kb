<?php
global $justify;
global $magmenu;
global $menuh;
global $vmenuh;
global $ocmenu;
$magmenu = false;
$menuh = false;
$ocmenu = true;
$justify = false;
global $cssprefix;
$cssprefix="ttr_";
global $fontSize1, $style1, $sidebarmenuheading;
$style1="";
$sidebarmenuheading = get_option('ttr_sidebarmenuheading');
$fontSize1 = get_option('ttr_font_size_sidebarmenu');
add_shortcode( 'widget', 'my_widget_shortcode' );
function my_widget_shortcode( $atts ) {
global $cssprefix;
extract( shortcode_atts(
array(
'type'  => '',
'title' => '',
'style' => '',
),
$atts));
if($style=='block'):
$args = array(
'before_widget' => '<div class="'.$cssprefix.'block"><div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>',
'after_widget'  => '</div>',
'before_title'  => '<div class="'.$cssprefix.'block_header"><h3 style="color:#FFFFFF;font-size:16px;margin: 0 5px;"class="'.$cssprefix.'block_heading">',
'after_title'   => '</h3></div>',
);
else:
$args = array(
'before_widget' => '<div class="box widget">',
'after_widget'  => '</div>',
'before_title'  => '<div class="widget-title">',
'after_title'   => '</div>',
);
endif;
the_widget( $type, $atts, $args );
}
add_action('wp_enqueue_scripts', 'my_scripts_method');
function my_scripts_method() {
wp_enqueue_script('jquery');
if(get_option('ttr_back_to_top',true)): 
endif;
}
function twentythirteen_widgets_init() {
global $cssprefix;
$cssprefix="ttr_";
global $theme_widget_args;
global $fontSize, $style;
$style="";
  $blockheading = get_option('ttr_blockheading');
  $fontSize = get_option('ttr_font_size_block');
 if(!empty($blockheading)){
 $style .= "color:".$blockheading.";";
 }
 if(!empty($fontSize)){
 $style .= "font-size:".$fontSize."px;";
 }
if(isset($_POST['wp_customize']) && $_POST['wp_customize']=='on'):
$theme_widget_args = array('before_widget' => '<div class="'.$cssprefix.'block"><div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div> <div class="'.$cssprefix.'block_header">',
'after_widget' => '</div></div>~tt',
'before_title' => '<h3 style="'.$style.'" class="'.$cssprefix.'block_heading">
',
'after_title' => '</h3></div> <div id="%1$s" class="'.$cssprefix.'block_content">',
);
else:
$theme_widget_args = array('before_widget' => '<div class="'.$cssprefix.'block"><div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div> <div class="'.$cssprefix.'block_header">',
'after_widget' => '</div></div>~tt',
'before_title' => '<'.get_option('ttr_heading_tag_block','h3').' style="'.$style.'" class="'.$cssprefix.'block_heading">
',
'after_title' => '</'.get_option('ttr_heading_tag_block','h3').'></div> <div id="%1$s" class="'.$cssprefix.'block_content">',
);
endif;
extract($theme_widget_args);
register_sidebar( array(
'name' => __( 'Right Sidebar', CURRENT_THEME ),
'id' => 'sidebar-2',
'description' => __( 'The sidebar for the optional Showcase Template', CURRENT_THEME ),
'before_widget' => $before_widget,
'after_widget' => $after_widget,
'before_title' => $before_title,
'after_title' => $after_title,
) );
register_sidebar( array(
'name' => __( 'lagu', CURRENT_THEME ),
'id' => 'slideshowabovecolumn1',
'description' => __( 'An optional widget area for your site slideshow', CURRENT_THEME ),
'before_widget' => '<aside id="%1$s" class="widget %2$s">',
'after_widget' => "</aside>~tt",
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );
register_sidebar( array(
'name' => __( 'kontent utama', CURRENT_THEME ),
'id' => 'menubelowcolumn1',
'description' => __( 'An optional widget area for your site menu', CURRENT_THEME ),
'before_widget' => '<aside id="%1$s" class="widget %2$s">',
'after_widget' => "</aside>~tt",
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );
register_sidebar( array(
'name' => __( 'footer', CURRENT_THEME ),
'id' => 'contentbottomcolumn1',
'description' => __( 'An optional widget area for your site content', CURRENT_THEME ),
'before_widget' => '<aside id="%1$s" class="widget %2$s">',
'after_widget' => "</aside>~tt",
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );
}
add_action( 'widgets_init', 'twentythirteen_widgets_init' );?>